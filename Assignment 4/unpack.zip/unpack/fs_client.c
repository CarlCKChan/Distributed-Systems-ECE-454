#include <stdio.h>

int main(int argc, char *argv[]) {
    /* A dummy client app */
    printf("fsclient\n"); fflush(stdout);
    return 0;
}
