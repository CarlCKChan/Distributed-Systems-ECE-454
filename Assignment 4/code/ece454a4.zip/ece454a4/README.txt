Debin Li (d73li): 20389489
Carl Chan (c73chan): 20383063



/*******************************************
* Coding Style Rules
 *************************************************

 * Brackets on line after function signatures
                                                                    *
 * Function names are either all lowercase words separated by underscores for camel-case           
              *
 * All values passed by reference are declared as const, unless they must absolutely be changed
                  *
 * Source files do not need to have an accompanying header file if they are for library stubs
                    *
 * Constants are all capitalized, with words separated by underscores.  The words can be abbreviations.
          *
 *****************************************************************************************************************/